package bean;

public class boardVo {

}
