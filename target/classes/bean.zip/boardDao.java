package bean;

import org.apache.ibatis.session.SqlSession;

import myba.BoardFactory;

public class boardDao {
	SqlSession session;
	
	public boardDao(BoardFactory f){
		this.session=f.getFactory().openSession();
	}
}
