package bean;

public class SpringBoardController {
	boardDao dao;
	
	public SpringBoardController(boardDao dao){
		this.dao=dao;
	}
}
